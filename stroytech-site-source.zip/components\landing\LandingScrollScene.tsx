"use client";

import { useRef } from "react";
import { HeroContent } from "./HeroContent";
import { HouseSequenceCanvas } from "./HouseSequenceCanvas";
import { HouseStageFrame } from "./HouseStageFrame";
import { LuxuryStoryCard } from "./LuxuryStoryCard";
import { StoryProgress } from "./StoryProgress";
import {
  DESKTOP_SEQUENCE_FRAMES,
  MOBILE_SEQUENCE_FRAMES,
  STORY_STEPS,
} from "@/lib/landing-data";
import { SITE_CONTENT } from "@/data/siteContent";
import { useScrollFrame } from "@/hooks/useScrollFrame";

// Must match STEP_START / STEP_END in LuxuryStoryCard.tsx
const STEP_START = 0.26;
const STEP_END = 0.92;

/**
 * Cinematic atmosphere — house остаётся читаемым, без «грязной» подложки.
 * Только градиенты (GPU-friendly), без filter на весь кадр.
 */
function SceneAtmosphere() {
  return (
    <div
      aria-hidden
      className="pointer-events-none absolute inset-0 z-[2]"
    >
      {/* Фасад — мягкий центральный pool света */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse 64% 52% at 50% 55%, rgba(243,239,230,0.20) 0%, rgba(243,239,230,0.05) 48%, transparent 70%)",
        }}
      />
      {/* Верх — лёгкий bloom, воздух у горизонта */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse 130% 58% at 50% -12%, rgba(255,252,244,0.32) 0%, transparent 55%)",
        }}
      />
      {/* Низ — тёплый подъём под editorial-панель, без тяжёлого затемнения */}
      <div
        className="absolute inset-x-0 bottom-0"
        style={{
          height: "62%",
          background:
            "linear-gradient(to top, rgba(238,232,220,0.26) 0%, rgba(241,236,226,0.09) 44%, transparent 74%)",
        }}
      />
      {/* Едва заметная равномерная вуаль — contrast чуть мягче */}
      <div
        className="absolute inset-0"
        style={{ background: "rgba(238,234,224,0.065)" }}
      />
      {/* Виньетка по краям — кинематограф, не blackout */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse 92% 92% at 50% 48%, transparent 38%, rgba(44,40,36,0.04) 72%, rgba(38,34,30,0.065) 100%)",
        }}
      />
    </div>
  );
}

export function LandingScrollScene() {
  const sceneSectionRef = useRef<HTMLElement>(null);
  const { scrollProgress } = useScrollFrame({
    sectionRef: sceneSectionRef,
    timelineFrames: DESKTOP_SEQUENCE_FRAMES,
  });

  const progress01 = scrollProgress;
  const heroData   = SITE_CONTENT.hero;

  // Synthetic step windows for StoryProgress dots
  const stepRange    = (STEP_END - STEP_START) / STORY_STEPS.length;
  const progressSteps = STORY_STEPS.map((step, i) => ({
    id: `step-${i}`,
    startProgress: STEP_START + i * stepRange,
    label: step.eyebrow,
  }));

  return (
    <div className="relative text-ink">
      <section
        id="services"
        ref={sceneSectionRef}
        className="relative isolate"
        aria-label="Сцена прокрутки"
      >
        {/*
         * ── Sticky canvas + все overlays ──────────────────────────────
         *
         * Единый sticky контейнер для canvas, атмосферы, hero и карточки.
         * LuxuryStoryCard центрируется поверх дома и меняет контент внутри.
         *
         * Scroll distance — из spacer h-[800vh] ниже.
         * Total section = 100vh (sticky) + 800vh (spacer) = 900vh.
         * sectionScrollProgress range = 800vh → progress 0..1.
         */}
        {/*
         * Z-index (ниже header z-50):
         *   0  — canvas
         *   2  — SceneAtmosphere
         *   4  — scene-grain-layer (globals)
         *  22 — HeroContent (открытие сцены)
         *  24 — LuxuryStoryCard (редакционный слой поверх дома)
         *  28 — StoryProgress
         */}
        <div className="sticky top-0 z-[1] h-screen min-h-0 w-full overflow-hidden">

          {/*
           * Canvas wrapper with canvas-breathe animation.
           * Very subtle 0.7% scale over 18s — house "breathes" gently.
           * overflow:hidden on parent clips any edge bleed.
           */}
          <div className="absolute inset-0 z-0 canvas-breathe" aria-hidden>
            <HouseStageFrame>
              <HouseSequenceCanvas
                desktopFrames={DESKTOP_SEQUENCE_FRAMES}
                mobileFrames={MOBILE_SEQUENCE_FRAMES}
                progress01={progress01}
                className="pointer-events-none"
              />
            </HouseStageFrame>
          </div>

          {/* Cinematic atmosphere — warm layers over the house */}
          <SceneAtmosphere />

          {/* Film grain texture */}
          <div className="scene-grain-layer" aria-hidden />

          {/* Hero content — cinematic dissolve (opacity + blur + scale) */}
          <HeroContent variant="mobile"  data={heroData} progress01={progress01} />
          <HeroContent variant="desktop" data={heroData} progress01={progress01} />

          <LuxuryStoryCard progress01={progress01} />

          {/*
           * Прогресс-линия — над карточкой по z-index, узкая зона справа.
           */}
          <StoryProgress steps={progressSteps} progress01={progress01} />
        </div>

        {/*
         * ── Scroll spacer ────────────────────────────────────────────
         * 800vh spacer → section total 900vh → range 800vh → progress 0..1.
         * Slower pacing: each editorial panel stable for ~96vh of scroll.
         */}
        <div className="h-[800vh]" aria-hidden />
      </section>
    </div>
  );
}
