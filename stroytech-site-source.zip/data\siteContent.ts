/**
 * siteContent.ts — единственный источник всех текстовых данных лендинга.
 * Замените placeholder-значения на реальный контент клиента.
 *
 * Механика scroll-sequence и canvas управляется через lib/landing-data.ts.
 */

import { PORTFOLIO_IMAGE_BLUR_DATA_URL } from "./portfolioMedia";

// ─── Типы ────────────────────────────────────────────────────────────────────

export interface SiteMeta {
  title: string;
  description: string;
}

export interface SiteHero {
  brand: string;
  /** Строки заголовка — 3 editorial-линии без «висячих» предлогов (см. вёрстку) */
  headlineLines: string[];
  /** Верхняя meta-строка обложки (uppercase в вёрстке) */
  coverEyebrow: string;
  tagline: string;
  /** Подзаголовок hero-секции */
  subheadline: string;
  /** Текст основной CTA-кнопки */
  ctaPrimary: string;
  /** Текст второстепенной CTA-ссылки */
  ctaSecondary: string;
  /** Микроподпись под блоком CTA */
  ctaCaption: string;
}

/**
 * Карточка cinematic scroll-sequence.
 * startProgress / endProgress — доля скролла 0..1, когда карточка видима.
 * На desktop и mobile используется progress-driven анимация.
 */
export interface SceneCard {
  id: string;
  eyebrow: string;
  title: string;
  text: string;
  items?: string[];
  side: "left" | "right";
  /** Вертикальная позиция карточки внутри слота (только desktop) */
  align?: "top" | "middle" | "bottom";
  /** Доля прогресса, с которой карточка начинает появляться (0..1) */
  startProgress: number;
  /** Доля прогресса, после которой карточка исчезает (0..1) */
  endProgress: number;
}

export interface PortfolioItem {
  title: string;
  location: string;
  area: string;
  year: string;
  /** Тип работ / объект */
  tag: string;
  /** Одна редакционная строка под объектом */
  caption: string;
  /** Статус («Сдано», «В эксплуатации»); год остаётся отдельным полем */
  status?: string;
  /** Путь в `/public` — при наличии показывается вместо плейсхолдера */
  imageSrc?: string;
  /** Крошечный data URL для `next/image` `placeholder="blur"` при заданном `imageSrc` */
  blurDataURL?: string;
}

export interface SitePortfolio {
  /** Редакционная meta над заголовком */
  eyebrowLine: string;
  heading: string;
  /** Короткое описание каталога секции */
  description: string;
  items: PortfolioItem[];
}

export interface SiteContacts {
  /** Редакционная строка над заголовком секции контактов */
  sectionLabel: string;
  /** Крупный заголовок (serif на стороне дизайна) */
  heading: string;
  /** Уверенное короткое описание приглашения */
  subheading: string;
  /** Телефон для набора tel: */
  phone: string;
  /** Контакт мессенджера — подпись */
  messengerLabel: string;
  /** Ссылка мессенджера (tg / wa.me и т.д.) */
  messengerHref: string;
  /** Короткая строка email */
  email: string;
  /** Город / регион работы */
  locality: string;
  /** При необходимости — офисный адрес (одна строка) */
  address?: string;
  /** Режим работы строкой */
  workingHours: string;
  /** Подпись основной кнопки формы */
  ctaLabel: string;
  /** Микродоверительный текст под кнопкой */
  trustNote: string;
  /** Шаги «как после заявки» — короткие фразы */
  processSteps: string[];
}

export interface SiteContent {
  meta: SiteMeta;
  hero: SiteHero;
  /** 5 карточек поверх cinematic scroll-сцены */
  sceneCards: SceneCard[];
  portfolio: SitePortfolio;
  contacts: SiteContacts;
}

// ─── Контент ─────────────────────────────────────────────────────────────────

export const SITE_CONTENT: SiteContent = {
  // ── Мета ──────────────────────────────────────────────────────────────────
  meta: {
    title: "СТРОЙ ТЕХНОЛОГИЯ — частные дома и реконструкция под ключ",
    description:
      "Коттеджи и реконструкция в Оренбурге и области: проект, строительство под ключ, сдача с документами. СРО. ДОМ.РФ, Сбербанк.",
  },

  // ── Hero ──────────────────────────────────────────────────────────────────
  hero: {
    brand: "СТРОЙ ТЕХНОЛОГИЯ",
    headlineLines: [
      "Частные дома",
      "с архитектурной",
      "точностью",
    ],
    coverEyebrow: "2026 · ЧАСТНАЯ ЗАСТРОЙКА / РЕКОНСТРУКЦИЯ",
    tagline: "Оренбург и область · частные дома под ключ",
    subheadline:
      "Проектируем, строим и сдаём дома в единой системе: со сметой, этапами и контролем качества.",
    ctaPrimary: "Назначить консультацию",
    ctaSecondary: "Смотреть подход",
    ctaCaption:
      "Первичный разбор участка, задачи и бюджета — перед началом проектирования.",
  },

  // ── Карточки cinematic scroll-сцены ───────────────────────────────────────
  //
  // Scroll distance: 800vh (spacer h-[800vh] + section h-screen = 900vh total).
  // FADE_RATIO = 0.125 → 12.5% вход / 75% стабильно / 12.5% выход.
  //
  // Все карточки — единая позиция: bottom-left editorial panel.
  // Hero растворяется к progress 0.15. Первая карточка появляется с 0.16.
  // Окна строго НЕ ПЕРЕСЕКАЮТСЯ (gap = 0.01 между слотами).
  // В любой момент видна только одна карточка.
  //
  // Прогрессовые окна (window = 0.16, gap = 0.01, range = 800vh):
  //   why-us:     0.16 – 0.32   stable ≈ 96vh   fade ≈ 16vh
  //   services:   0.33 – 0.49   stable ≈ 96vh   fade ≈ 16vh
  //   guarantees: 0.50 – 0.66   stable ≈ 96vh   fade ≈ 16vh
  //   process:    0.67 – 0.83   stable ≈ 96vh   fade ≈ 16vh
  //   documents:  0.84 – 1.00   stable ≈ 102vh  fade ≈ 17vh
  sceneCards: [
    {
      id: "why-us",
      eyebrow: "О СТУДИИ",
      title: "Строим дома, а не обещания",
      text: "Работаем в Оренбурге и области с частными заказчиками, для которых важны ясная смета, сроки и спокойная сдача без сюрпризов на объекте.",
      items: [
        "Коттеджи и реконструкция под ключ",
        "СРО и аккредитации ДОМ.РФ, Сбербанк",
        "Портфель закрытых объектов в регионе",
        "Один подрядчик от проекта до ключей",
      ],
      side: "left",
      startProgress: 0.16,
      endProgress: 0.32,
    },
    {
      id: "services",
      eyebrow: "СПЕКТР РАБОТ",
      title: "От чертежа до передачи",
      text: "Берём на себя проектирование, новое строительство и реконструкцию: коробка, кровля, фасад, инженерия и отделка в согласованном графике.",
      items: [
        "Новые частные дома и коттеджи",
        "Реконструкция и пристройки",
        "Кирпич, газобетон, газоблок",
        "Коммерческие объекты по запросу",
      ],
      side: "left",
      startProgress: 0.33,
      endProgress: 0.49,
    },
    {
      id: "guarantees",
      eyebrow: "ДИСЦИПЛИНА",
      title: "Условия зафиксированы заранее",
      text: "Смета, этапы и объём работ записываем в договор до выхода на площадку. Приёмка — по регламенту, с документами на каждый значимый слой.",
      items: [
        "Смета и календарь в контракте",
        "Оплата по факту этапов",
        "Материалы с подтверждённым происхождением",
        "Технический надзор на площадке",
      ],
      side: "left",
      startProgress: 0.5,
      endProgress: 0.66,
    },
    {
      id: "process",
      eyebrow: "КАК МЫ ВЕДЁМ ДОМ",
      title: "Шесть понятных глав",
      text: "От проекта до передачи ключей — последовательность, в которой видно, что сделано сегодня и что открывается завтра.",
      items: [
        "Встреча и разбор участка или дома",
        "Эскиз сметы и договор",
        "Строительство по утверждённым этапам",
        "Сдача с актами и комплектом документов",
      ],
      side: "left",
      startProgress: 0.67,
      endProgress: 0.83,
    },
    {
      id: "documents",
      eyebrow: "ОФОРМЛЕНИЕ",
      title: "Готово для банка и эксплуатации",
      text: "Работаем в легальном поле: членство в СРО, аккредитации, исполнительная документация — без «серых» схем и дыр в пакете.",
      items: [
        "Документы СРО",
        "Аккредитации ДОМ.РФ и Сбербанка",
        "Договор и закрывающая отчётность",
        "Исполнительная документация объекта",
      ],
      side: "left",
      startProgress: 0.84,
      endProgress: 1.0,
    },
  ],

  // ── Портфолио ─────────────────────────────────────────────────────────────
  portfolio: {
    eyebrowLine: "Проекты · избранные объекты",
    heading: "Коллекция частных и коммерческих объёмов",
    description:
      "Кураторский каталог реализованных работ: от городского дома до промышленной площадки. Объекты отобраны как репрезентативная линейка полного цикла студии.",
    items: [
      {
        title: "Резиденция на Транспортной",
        location: "Оренбург, частный сектор",
        area: "240 м²",
        year: "2024",
        tag: "Частный дом · под ключ",
        status: "Сдано · эксплуатация",
        caption:
          "Один контур: фасад, кровля и инженерия согласованы в рабочей ведомости — без разрыва между архитектурой и площадкой.",
        imageSrc: "/portfolio/project-01-residence-transportnaya.jpg",
        blurDataURL: PORTFOLIO_IMAGE_BLUR_DATA_URL,
      },
      {
        title: "Павильон у Лётной",
        location: "Оренбург, коммерческая зона",
        area: "380 м²",
        year: "2024",
        tag: "Коммерческое строительство",
        status: "Сдано",
        caption:
          "Короткие сроки ввода за счёт синхронизации конструктива и облицовочного контура.",
        imageSrc: "/portfolio/project-02-pavilion-letnaya.jpg",
        blurDataURL: PORTFOLIO_IMAGE_BLUR_DATA_URL,
      },
      {
        title: "Цех в пригороде",
        location: "Оренбургская область",
        area: "1 200 м²",
        year: "2023",
        tag: "Промышленный объект",
        status: "Эксплуатация",
        caption:
          "Каркас и инженерия под производственный график: чёткие отметки для дальнейших линий цеха.",
        imageSrc: "/portfolio/project-03-workshop-outskirts.jpg",
        blurDataURL: PORTFOLIO_IMAGE_BLUR_DATA_URL,
      },
      {
        title: "Коттедж в Нежинке",
        location: "Оренбург, Нежинка",
        area: "180 м²",
        year: "2023",
        tag: "Газобетон · отделка",
        status: "Сдано семье",
        caption:
          "Лаконичный силуэт и тёплый фасад без лишнего декора — спокойная среда участка.",
        imageSrc: "/portfolio/project-04-cottage-nezhinka.jpg",
        blurDataURL: PORTFOLIO_IMAGE_BLUR_DATA_URL,
      },
      {
        title: "Офисный блок, центр",
        location: "Оренбург, центр",
        area: "650 м²",
        year: "2022",
        tag: "Реконструкция",
        status: "В работе офиса",
        caption:
          "Внутренние контуры и трассировка сохранены в одном BIM-плоскости с фасадами точки входа.",
        imageSrc: "/portfolio/project-05-office-center.jpg",
        blurDataURL: PORTFOLIO_IMAGE_BLUR_DATA_URL,
      },
      {
        title: "Дом на Форштадте",
        location: "Оренбург, Форштадт",
        area: "210 м²",
        year: "2022",
        tag: "Кирпич · фасад",
        status: "Сдано",
        caption:
          "Классический кирпичный контур и глубина проёма: свет во двор сохранён по проекту.",
        imageSrc: "/portfolio/project-06-house-forshtadt.jpg",
        blurDataURL: PORTFOLIO_IMAGE_BLUR_DATA_URL,
      },
    ],
  },

  // ── Контакты ──────────────────────────────────────────────────────────────
  contacts: {
    sectionLabel: "Консультация архитектурной студии",
    heading: "Обсудим ваш будущий дом",
    subheading:
      "Расскажите, какой дом вы хотите построить. Мы уточним задачу, участок, формат работ и предложим следующий шаг.",
    phone: "+7 (353) 000-00-00",
    messengerLabel: "WhatsApp или Telegram — как удобнее",
    messengerHref: "https://wa.me/79008000001",
    email: "info@stroytech56.ru",
    locality: "Оренбург и Оренбургская область",
    address: "Офис: Оренбург, ул. Пример, 1",
    workingHours: "Будни · 10:00–18:00 по предварительной записи",
    ctaLabel: "Получить консультацию",
    trustNote:
      "Ответим, уточним задачу и предложим следующий шаг без навязчивых звонков.",
    processSteps: [
      "Вы оставляете контур задачи — мы отвечаем в том же ключе спокойного разговора.",
      "При необходимости уточняем участок, текущий дом и формат ведения: проектирование, стройка или реконструкция.",
      "Согласуем слот звонка или встречи и фиксируем, каким будет разумный следующий шаг.",
    ],
  },
};
