"use client";

import Image from "next/image";
import { useInViewOnce } from "@/hooks/useInViewOnce";
import { EASE_LUXURY_CSS_COMPACT, MOTION_DURATION_MS } from "@/lib/motion-system";
import type { PortfolioItem } from "@/data/siteContent";
import { SITE_CONTENT } from "@/data/siteContent";

const { portfolio } = SITE_CONTENT;

const ENTRY_MS = MOTION_DURATION_MS.section;
const STAGGER_MS = MOTION_DURATION_MS.staggerPortfolio;
const CARD_MICRO_MS = MOTION_DURATION_MS.card;

function CatalogImagePlaceholder({
  index,
  featured,
}: {
  index: number;
  featured: boolean;
}) {
  const num = String(index + 1).padStart(2, "0");
  return (
    <div className="pointer-events-none relative isolate size-full min-h-[12rem]">
      <div
        className="absolute inset-0"
        style={{
          background:
            "linear-gradient(145deg, rgba(250,247,240,0.98) 0%, rgba(241,235,226,0.92) 42%, rgba(226,216,198,0.86) 100%)",
        }}
      />
      <div
        aria-hidden
        className="absolute inset-0 opacity-[0.4]"
        style={{
          backgroundImage:
            "linear-gradient(rgba(72,54,40,0.045) 1px,transparent 1px)," +
            "linear-gradient(90deg,rgba(72,54,40,0.036) 1px,transparent 1px)",
          backgroundSize: "22px 22px",
        }}
      />
      <div
        aria-hidden
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse 74% 50% at 72% 18%, rgba(255,253,246,0.62) 0%, transparent 58%)",
        }}
      />
      <div
        className={
          featured
            ? "absolute left-7 top-7 font-display text-[2.75rem] font-medium tracking-[0.12em] text-ink/[0.14] tabular-nums lg:left-10 lg:top-9 lg:text-[3.4rem]"
            : "absolute left-6 top-6 font-display text-[2.1rem] font-medium tracking-[0.1em] text-ink/[0.12] tabular-nums lg:left-8 lg:text-[2.35rem]"
        }
      >
        {num}
      </div>
      <div className="absolute inset-0 flex items-center justify-center px-12 pb-[7%] pt-[16%]">
        <svg
          viewBox="0 0 120 92"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          aria-hidden
          className={
            featured
              ? "w-[min(74%,340px)] text-ink/[0.19]"
              : "w-[min(69%,268px)] text-ink/[0.16]"
          }
        >
          <path
            d="M28 74V44L60 20l32 24v30"
            stroke="currentColor"
            strokeWidth="0.75"
            strokeLinejoin="round"
          />
          <path d="M28 74h64" stroke="currentColor" strokeWidth="0.75" />
          <rect
            x="47"
            y="46"
            width="26"
            height="28"
            stroke="currentColor"
            strokeWidth="0.65"
            rx="1"
          />
          <path d="M52 61h16M60 54v17" stroke="currentColor" strokeWidth="0.45" />
          <circle
            cx="60"
            cy="28"
            r="1.35"
            fill="currentColor"
            fillOpacity="0.26"
          />
        </svg>
      </div>
      <div
        aria-hidden
        className="absolute inset-x-0 bottom-0 h-[34%]"
        style={{
          background:
            "linear-gradient(to top, rgba(237,229,216,0.38) 0%, transparent)",
        }}
      />
    </div>
  );
}

function PortfolioCatalogCard({
  item,
  index,
  variant,
  delay,
  /** Первые 1–2 карточки (эвристика «above-the-fold») — eager + priority */
  imagePriority = false,
}: {
  item: PortfolioItem;
  index: number;
  variant: "featured" | "default";
  delay: number;
  imagePriority?: boolean;
}) {
  const featured = variant === "featured";
  const { ref, isInView } = useInViewOnce<HTMLElement>({
    rootMargin: "0px 0px -10% 0px",
    threshold: 0,
  });
  const status = item.status ?? "Завершён";
  const titleId = `portfolio-project-${index}`;

  return (
    <article
      ref={ref}
      aria-labelledby={titleId}
      className={[
        "group/card relative overflow-hidden rounded-[clamp(18px,2.4vw,24px)]",
        "border border-[rgba(72,54,40,0.1)] bg-[rgba(251,246,239,0.52)] shadow-[inset_0_1px_0_rgba(255,252,246,0.66)]",
        "transition-colors duration-[720ms]",
        "[transition-timing-function:cubic-bezier(0.22,1,0.36,1)]",
        "lg:hover:border-[rgba(105,82,58,0.26)] lg:hover:bg-[rgba(255,251,243,0.72)] lg:hover:shadow-[0_40px_76px_-50px_rgba(36,28,22,0.2)]",
        "motion-reduce:transition-none",
      ].join(" ")}
      style={{
        opacity: isInView ? 1 : 0,
        transform: isInView ? "translateY(0)" : "translateY(26px)",
        transition: [
          `opacity ${ENTRY_MS}ms ${EASE_LUXURY_CSS_COMPACT}`,
          `transform ${ENTRY_MS}ms ${EASE_LUXURY_CSS_COMPACT}`,
          `border-color ${CARD_MICRO_MS}ms ${EASE_LUXURY_CSS_COMPACT}`,
          `background-color ${CARD_MICRO_MS}ms ${EASE_LUXURY_CSS_COMPACT}`,
          `box-shadow ${CARD_MICRO_MS}ms ${EASE_LUXURY_CSS_COMPACT}`,
        ].join(", "),
        transitionDelay: `${delay}ms`,
      }}
    >
      <div
        className={
          featured
            ? "relative aspect-[3/4] overflow-hidden sm:aspect-[17/13] xl:aspect-[21/13]"
            : "relative aspect-[3/4] overflow-hidden sm:aspect-[11/13] xl:aspect-[13/14]"
        }
      >
        <div className="absolute inset-0 z-[1] size-full origin-center motion-reduce:transition-none motion-reduce:lg:scale-100 lg:transition-transform lg:duration-[800ms] lg:ease-[cubic-bezier(0.22,1,0.36,1)] lg:group-hover/card:scale-[1.026]">
          {item.imageSrc ? (
            <>
              <Image
                src={item.imageSrc}
                alt={item.title}
                fill
                priority={imagePriority}
                {...(imagePriority
                  ? {}
                  : { loading: "lazy" as const })}
                {...(item.blurDataURL
                  ? {
                      placeholder: "blur" as const,
                      blurDataURL: item.blurDataURL,
                    }
                  : {})}
                quality={84}
                sizes={
                  featured
                    ? "(max-width: 1024px) 96vw, 58vw"
                    : "(max-width: 1024px) 96vw, 32vw"
                }
                className="object-cover object-center brightness-[1.025] saturate-[0.93] contrast-[0.96]"
              />
              <div
                aria-hidden
                className="pointer-events-none absolute inset-0 z-[2] bg-gradient-to-b from-[rgba(255,251,246,0.44)] via-[rgba(251,246,237,0.12)] to-[rgba(236,229,217,0.38)]"
              />
              <div
                aria-hidden
                className="pointer-events-none absolute inset-0 z-[3] bg-[rgba(246,239,229,0.05)] mix-blend-multiply"
              />
            </>
          ) : (
            <CatalogImagePlaceholder featured={featured} index={index} />
          )}
        </div>
      </div>

      <div className="px-[clamp(1.05rem,4vw,1.95rem)] pb-[clamp(1.2rem,4.2vw,1.95rem)] pt-[clamp(1.2rem,4.5vw,2.05rem)] transition-[transform] duration-[780ms] ease-[cubic-bezier(0.22,1,0.36,1)] lg:transition-[transform] lg:duration-[760ms] lg:motion-reduce:transition-none lg:group-hover/card:-translate-y-1 lg:motion-reduce:group-hover/card:translate-y-0 motion-reduce:transition-none motion-reduce:lg:translate-y-0 motion-reduce:lg:group-hover/card:translate-y-0">
        <div className="flex flex-wrap items-center gap-x-2 gap-y-1 border-b border-[rgba(105,82,58,0.085)] pb-4">
          <span className="font-sans text-[12px] font-semibold uppercase tracking-[0.21em] text-ink/[0.48] sm:text-[13px] lg:text-[11px]">
            {item.year}
          </span>
          <span
            aria-hidden
            className="h-[3px] w-[3px] shrink-0 rounded-full bg-[rgba(105,82,58,0.32)]"
          />
          <span className="font-sans text-[12px] font-medium uppercase tracking-[0.2em] text-ink/[0.44] sm:text-[12.5px] lg:text-[10.75px]">
            {status}
          </span>
        </div>

        <h3
          id={titleId}
          className={`mt-5 max-w-[20ch] text-balance font-display font-medium leading-[1.04] tracking-[-0.024em] text-ink/[0.96] ${
            featured
              ? "text-[clamp(1.75rem,4.35vw,2.75rem)]"
              : "text-[clamp(1.5rem,3.85vw,1.92rem)]"
          }`}
        >
          {item.title}
        </h3>

        <div className="mt-5 px-px">
          <div
            className="h-[1px] w-full origin-left scale-x-100 rounded-full bg-gradient-to-r from-[rgba(105,82,58,0.52)] via-ink/[0.18] to-ink/[0.05] motion-reduce:scale-x-100 lg:scale-x-[0.28] lg:transition-transform lg:duration-[720ms] lg:ease-[cubic-bezier(0.22,1,0.36,1)] lg:group-hover/card:scale-x-100 lg:motion-reduce:scale-x-100"
            aria-hidden
          />
        </div>

        <div className="mt-6 flex flex-col gap-x-4 gap-y-2 sm:flex-row sm:flex-wrap sm:items-center sm:gap-x-5">
          <span className="font-sans text-[0.98rem] font-medium leading-snug text-ink/[0.74] sm:text-[1.04rem]">
            {item.location}
          </span>
          <span
            aria-hidden
            className="hidden min-h-[1lh] items-center justify-center sm:flex sm:min-h-0"
          >
            <span className="h-[3px] w-[3px] rounded-full bg-ink/[0.24]" />
          </span>
          <span className="font-sans text-[0.98rem] font-medium tabular-nums leading-snug text-ink/[0.72] sm:text-[1.04rem]">
            {item.area}
          </span>
        </div>

        <span className="mt-5 inline-flex max-w-full items-center rounded-md border border-[rgba(105,82,58,0.28)] bg-[rgba(255,251,246,0.35)] px-3.5 py-2 font-sans text-[11.5px] font-semibold uppercase leading-tight tracking-[0.26em] text-ink/[0.58] sm:text-[11.75px] lg:text-[10.75px]">
          {item.tag}
        </span>

        <p className="mt-6 border-t border-[rgba(105,82,58,0.06)] pt-5 font-sans text-[1.055rem] font-medium leading-[1.62] tracking-[-0.01em] text-ink/[0.71] max-lg:text-ink/[0.74] sm:text-[1.06rem] sm:leading-[1.62] lg:text-[1rem] lg:leading-[1.6] lg:text-ink/[0.68]">
          {item.caption}
        </p>
      </div>
    </article>
  );
}

export function PortfolioSection() {
  const { ref: headRef, isInView: headInView } = useInViewOnce<HTMLElement>({
    rootMargin: "0px 0px -12% 0px",
    threshold: 0,
  });

  const items = portfolio.items;
  if (items.length === 0) {
    return (
      <section
        className="bg-paper-soft py-[clamp(4.75rem,10vw,7.75rem)]"
        aria-labelledby="portfolio-heading"
      >
        <div className="mx-auto max-w-[min(1250px,100%)] px-5">
          <h2 id="portfolio-heading" className="font-display">
            {portfolio.heading}
          </h2>
          <p className="font-sans text-muted">Объекты скоро появятся.</p>
        </div>
      </section>
    );
  }

  const [featuredItem, ...rest] = items;
  const sidebar = rest.slice(0, 2);
  const tail = rest.slice(2);

  let slot = 0;
  const delayFor = () => slot++ * STAGGER_MS;

  return (
    <section
      className="relative overflow-hidden bg-paper-soft py-[clamp(4.75rem,10vw,7.75rem)]"
      aria-labelledby="portfolio-heading"
    >
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse 90% 70% at 12% -8%, rgba(255,251,243,0.86) 0%, transparent 55%)," +
            "radial-gradient(ellipse 60% 50% at 98% 12%, rgba(238,229,218,0.35) 0%, transparent 45%)",
        }}
      />

      <div className="relative mx-auto max-w-[min(1250px,100%)] px-4 pt-px xs:px-5 sm:px-8 lg:px-14 xl:px-[4.25rem]">
        <header
          ref={headRef}
          className="mb-[clamp(2.85rem,6vw,4.65rem)] max-w-none lg:mb-[clamp(4rem,6.5vw,5.75rem)]"
          style={{
            opacity: headInView ? 1 : 0,
            transform: headInView ? "translateY(0)" : "translateY(18px)",
            transition: `opacity ${ENTRY_MS}ms ${EASE_LUXURY_CSS_COMPACT}, transform ${ENTRY_MS}ms ${EASE_LUXURY_CSS_COMPACT}`,
          }}
        >
          <div className="flex flex-col gap-10 lg:grid lg:grid-cols-[minmax(0,1fr)_min(36ch,min(100%,30rem))] lg:gap-x-24 lg:gap-y-0">
            <div className="min-w-0">
              <p className="m-0 max-w-fit font-sans text-[11.5px] font-semibold uppercase leading-relaxed tracking-[0.52em] text-ink/[0.44] sm:text-[12px] sm:tracking-[0.54em]">
                {portfolio.eyebrowLine}
              </p>
              <h2
                id="portfolio-heading"
                className="mt-[1.125rem] max-w-[20ch] text-balance font-display text-[clamp(2.05rem,4.95vw,3.65rem)] font-medium leading-[1.02] tracking-[-0.028em] text-ink/[0.97]"
              >
                {portfolio.heading}
              </h2>
            </div>
            <div className="flex min-h-0 shrink-0 items-start lg:border-l lg:border-[rgba(105,82,58,0.08)] lg:pl-[clamp(2rem,3.5vw,3.25rem)]">
              <p className="m-0 pt-px font-sans text-[clamp(1.02rem,2.05vw,1.11rem)] font-medium leading-[1.74] tracking-[-0.01em] text-ink/[0.74] lg:leading-[1.78] lg:tracking-[-0.008em]">
                {portfolio.description}
              </p>
            </div>
          </div>
        </header>

        {/* Mobile — одна колонка */}
        <div className="flex flex-col gap-[clamp(3rem,7vw,4rem)] sm:gap-16 lg:hidden">
          {items.map((item, i) => (
            <PortfolioCatalogCard
              key={item.title}
              item={item}
              index={i}
              variant={i === 0 ? "featured" : "default"}
              delay={i * STAGGER_MS}
              imagePriority={i < 2}
            />
          ))}
        </div>

        {/* Desktop — featured + столбец, затем три равные */}
        <div className="hidden flex-col gap-20 lg:flex">
          <div className="flex flex-col gap-[3.125rem] xl:flex-row xl:items-start xl:gap-x-14">
            <div className="w-full xl:w-[60%] xl:max-w-none xl:shrink-0 xl:self-stretch">
              <PortfolioCatalogCard
                key={featuredItem.title}
                item={featuredItem}
                index={0}
                variant="featured"
                delay={delayFor()}
                imagePriority
              />
            </div>
            <div className="flex flex-1 min-w-0 flex-col gap-[clamp(3rem,3.5vw,3.85rem)]">
              {sidebar.map((item, k) => {
                const idx = k + 1;
                const d = delayFor();
                return (
                  <PortfolioCatalogCard
                    key={item.title}
                    item={item}
                    index={idx}
                    variant="default"
                    delay={d}
                    imagePriority={k === 0}
                  />
                );
              })}
            </div>
          </div>

          <div className="grid gap-x-14 gap-y-[4.75rem] lg:grid-cols-3">
            {tail.map((item, k) => {
              const idx = k + sidebar.length + 1;
              const d = delayFor();
              return (
                <PortfolioCatalogCard
                  key={item.title}
                  item={item}
                  index={idx}
                  variant="default"
                  delay={d}
                />
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
