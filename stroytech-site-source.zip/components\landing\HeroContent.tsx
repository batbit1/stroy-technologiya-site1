"use client";

import type { MouseEvent, ReactNode } from "react";
import { motion, useReducedMotion } from "framer-motion";
import type { SiteHero } from "@/data/siteContent";
import { useMediaQuery } from "@/hooks/useMediaQuery";
import {
  EASE_LUXURY,
  EASE_LUXURY_CSS,
  HERO_STAGGER_S,
  MOTION_DURATION_MS,
  MOTION_DURATION_S,
} from "@/lib/motion-system";

type Props = {
  variant: "mobile" | "desktop";
  data: SiteHero;
  progress01?: number;
};

interface HeroDissolveState {
  opacity: number;
  blurPx: number;
  scale: number;
}

const HERO_FULL_END = 0.055;
const HERO_DISSOLVE_END = 0.195;

/** Слева: мягкая подложка. Справа/центр: дом без «мыльного» перекрытия. */
const HERO_SCRIM_LG = `
  linear-gradient(
    90deg,
    rgba(246, 239, 226, 0.86) 0%,
    rgba(246, 239, 226, 0.58) 28%,
    rgba(246, 239, 226, 0.12) 56%,
    transparent 78%
  ),
  linear-gradient(
    to top,
    rgba(38, 34, 29, 0.04) 0%,
    transparent 42%
  )
`;

/** Mobile: сохранить дом, текст не занимает весь экран. */
const HERO_SCRIM_MO = `
  linear-gradient(
    148deg,
    rgba(246, 239, 226, 0.78) 0%,
    rgba(246, 239, 226, 0.42) 36%,
    rgba(246, 239, 226, 0.08) 58%,
    transparent 74%
  ),
  linear-gradient(
    to top,
    rgba(38, 34, 29, 0.035) 0%,
    transparent 38%
  )
`;

function smoothstep01(t: number): number {
  const x = Math.max(0, Math.min(1, t));
  return x * x * (3 - 2 * x);
}

function heroDissolve(p: number): HeroDissolveState {
  const BLUR_CAP = 5.75;
  const SCALE_MIN = 0.994;

  if (p <= HERO_FULL_END) return { opacity: 1, blurPx: 0, scale: 1 };
  if (p >= HERO_DISSOLVE_END) {
    return { opacity: 0, blurPx: BLUR_CAP, scale: SCALE_MIN };
  }
  const u = (p - HERO_FULL_END) / (HERO_DISSOLVE_END - HERO_FULL_END);
  const e = smoothstep01(u);
  const opacityT = Math.pow(e, 0.74);
  const blurEase = smoothstep01(smoothstep01(e));

  return {
    opacity: 1 - opacityT,
    blurPx: BLUR_CAP * blurEase,
    scale: 1 - (1 - SCALE_MIN) * blurEase,
  };
}

function scrollTo(id: string) {
  return (e: MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };
}

/** Верхняя meta-линия журнальной обложки — одна строка. */
function CoverEyebrow({ text }: { text: string }) {
  return (
    <p className="m-0 mb-6 max-w-[760px] font-sans text-[11px] font-semibold uppercase leading-snug tracking-[0.22em] text-[rgba(32,28,23,0.54)] lg:mb-8 lg:text-[11.75px]">
      {text}
    </p>
  );
}

function HeroPremiumButton({
  href,
  onClick,
  children,
  fullWidthMobile,
}: {
  href: string;
  onClick: (e: MouseEvent<HTMLAnchorElement>) => void;
  children: ReactNode;
  fullWidthMobile?: boolean;
}) {
  return (
    <a
      href={href}
      onClick={onClick}
      style={{
        transitionDuration: `${MOTION_DURATION_MS.micro}ms`,
        transitionTimingFunction: EASE_LUXURY_CSS,
      }}
      className={[
        "group/hp relative isolate inline-flex min-h-[48px] items-center justify-center overflow-hidden rounded-full",
        "border border-[rgba(41,37,32,0.18)] px-[26px] py-[14px]",
        "font-sans text-[13px] font-semibold tracking-[0.035em] text-[rgba(28,24,20,0.94)] shadow-none",
        "transition-[transform,box-shadow]",
        "[@media(hover:hover)]:hover:-translate-y-px hover:shadow-[0_14px_36px_-20px_rgba(28,22,18,0.2)] active:translate-y-0 active:scale-[0.988]",
        "outline-none ring-offset-2 ring-offset-[var(--paper-soft)] focus-visible:ring-2 focus-visible:ring-[rgba(41,37,32,0.14)]",
        fullWidthMobile ? "w-full sm:w-auto" : "",
      ].join(" ")}
    >
      <span
        aria-hidden
        style={{
          transitionDuration: `${MOTION_DURATION_MS.lineReveal}ms`,
          transitionTimingFunction: EASE_LUXURY_CSS,
        }}
        className="pointer-events-none absolute inset-0 origin-left scale-x-0 bg-gradient-to-r from-[rgba(237,229,212,0.52)] via-[rgba(218,196,172,0.34)] to-[rgba(226,212,188,0.26)] opacity-95 transition-transform group-hover/hp:scale-x-100 group-focus-visible/hp:scale-x-100"
      />
      <span className="relative z-[1]">{children}</span>
    </a>
  );
}

function HeroSecondaryLink({
  href,
  onClick,
  children,
  centeredMobile,
}: {
  href: string;
  onClick: (e: MouseEvent<HTMLAnchorElement>) => void;
  children: ReactNode;
  centeredMobile?: boolean;
}) {
  return (
    <a
      href={href}
      onClick={onClick}
      style={{
        transitionDuration: `${MOTION_DURATION_MS.micro}ms`,
        transitionTimingFunction: EASE_LUXURY_CSS,
      }}
      className={[
        "group/hs relative inline-flex min-h-[48px] items-center justify-center py-2.5 font-sans text-[12px] font-semibold uppercase tracking-[0.2em]",
        "text-[rgba(32,28,23,0.58)] [@media(hover:hover)]:hover:text-[rgba(32,28,23,0.78)] focus-visible:text-[rgba(32,28,23,0.82)] focus-visible:outline-none",
        "sm:justify-start sm:tracking-[0.185em]",
        centeredMobile ? "w-full max-sm:mx-auto max-sm:flex" : "",
      ].join(" ")}
    >
      <span className="relative whitespace-nowrap">
        {children}
        <span
          aria-hidden
          style={{
            transitionDuration: `${MOTION_DURATION_MS.lineReveal}ms`,
            transitionTimingFunction: EASE_LUXURY_CSS,
          }}
          className={[
            "pointer-events-none absolute -bottom-[2px] left-0 right-0 h-px mx-auto bg-[rgba(32,28,23,0.22)] transition-[transform,opacity,width]",
            "origin-left scale-x-[0.2] opacity-85 w-[108%]",
            "[@media(hover:hover)]:group-hover/hs:scale-x-100 [@media(hover:hover)]:group-hover/hs:bg-[rgba(32,28,23,0.36)] [@media(hover:hover)]:group-hover/hs:opacity-100 group-focus-visible/hs:scale-x-100",
          ].join(" ")}
        />
      </span>
    </a>
  );
}

type RevealTimings = {
  yPx: number;
  blurPx: number;
  duration: number;
  delays: {
    meta: number;
    lines: number[];
    sub: number;
    cta: number;
    caption: number;
  };
  ease: typeof EASE_LUXURY;
};

function heroRevealTimings(
  lineCount: number,
  mobile: boolean,
  reduceFx: boolean,
): RevealTimings {
  if (reduceFx) {
    return {
      yPx: 0,
      blurPx: 0,
      duration: MOTION_DURATION_S.reduced,
      delays: {
        meta: 0,
        lines: Array.from({ length: lineCount }, () => 0),
        sub: 0,
        cta: 0,
        caption: 0,
      },
      ease: EASE_LUXURY,
    };
  }

  const step = mobile ? HERO_STAGGER_S.mobileStep : HERO_STAGGER_S.desktopStep;
  const baseDur = mobile
    ? MOTION_DURATION_S.heroTitle * 0.92
    : MOTION_DURATION_S.heroTitle;

  let t = mobile ? step * 0.42 : step * 0.5;
  const metaDelay = t;
  t += mobile ? step * 1.85 : step * 1.88;

  const lineDelays: number[] = [];
  for (let i = 0; i < lineCount; i++) {
    lineDelays.push(t);
    t += step * 0.88;
  }

  const subDelay = t + step * 0.48;
  const ctaDelay = subDelay + step * 0.82;
  const captionDelay = ctaDelay + step * 0.42;

  return {
    yPx: mobile ? 14 : 20,
    blurPx: mobile ? 5 : 6.25,
    duration: baseDur,
    delays: {
      meta: metaDelay,
      lines: lineDelays,
      sub: subDelay,
      cta: ctaDelay,
      caption: captionDelay,
    },
    ease: EASE_LUXURY,
  };
}

// ─── Desktop ─────────────────────────────────────────────────────────────────

function HeroDesktop({
  data,
  dissolve,
  reduceFx,
}: {
  data: SiteHero;
  dissolve: HeroDissolveState;
  reduceFx: boolean;
}) {
  const { opacity, blurPx, scale } = dissolve;
  const btnsPointerEvents = opacity < 0.05 ? "none" : "auto";
  const lines = data.headlineLines;
  const T = heroRevealTimings(lines.length, false, reduceFx);

  const softHidden = reduceFx
    ? { opacity: 0 }
    : { opacity: 0, y: T.yPx, filter: `blur(${T.blurPx}px)` };
  const softAlive = reduceFx
    ? { opacity: 1 }
    : { opacity: 1, y: 0, filter: "blur(0px)" };

  const softTran = (delay: number) => ({
    duration: T.duration,
    ease: T.ease,
    delay,
  });

  const titleStyle = {
    fontSize: "clamp(64px, 7.2vw, 118px)",
    lineHeight: 0.92,
    letterSpacing: "-0.055em",
    fontWeight: 500,
    color: "rgba(28, 24, 20, 0.96)",
  } as const;

  return (
    <div
      className="pointer-events-none absolute inset-0 z-[22] hidden lg:flex"
      style={{
        opacity,
        ...(blurPx > 0.08 ? { filter: `blur(${blurPx.toFixed(2)}px)` } : {}),
        ...(scale < 0.9995 ? { transform: `scale(${scale.toFixed(4)})` } : {}),
        willChange: "opacity, filter, transform",
      }}
    >
      <div
        aria-hidden
        className="absolute inset-0"
        style={{ background: HERO_SCRIM_LG }}
      />

      <div className="absolute inset-0 flex items-start justify-start">
        <div className="relative w-full max-w-[760px] pl-[clamp(40px,6vw,120px)] pr-[clamp(20px,3vw,48px)] pt-[max(7.25rem,min(22svh,calc(env(safe-area-inset-top,0px)+19.5svh)))]">
          <motion.div
            initial={softHidden}
            animate={{
              ...softAlive,
              transition: softTran(reduceFx ? 0 : T.delays.meta),
            }}
          >
            <CoverEyebrow text={data.coverEyebrow} />
          </motion.div>

          <h1 className="m-0 max-w-[760px] font-display font-medium">
            {lines.map((line, i) => (
              <motion.div
                key={`${i}-${line.slice(0, 8)}`}
                className="overflow-hidden"
                style={{ lineHeight: titleStyle.lineHeight }}
                initial={reduceFx ? false : { opacity: 0 }}
                animate={reduceFx ? undefined : { opacity: 1 }}
                transition={
                  reduceFx ? undefined : { duration: T.duration * 0.62, ease: T.ease }
                }
              >
                <motion.span
                  className="block font-display"
                  style={titleStyle}
                  initial={
                    reduceFx
                      ? { opacity: 0 }
                      : { y: "1.06em", opacity: 0, filter: `blur(${T.blurPx}px)` }
                  }
                  animate={
                    reduceFx
                      ? { opacity: 1 }
                      : { y: 0, opacity: 1, filter: "blur(0px)" }
                  }
                  transition={softTran(reduceFx ? 0 : T.delays.lines[i]!)}
                >
                  {line}
                </motion.span>
              </motion.div>
            ))}
          </h1>

          <motion.p
            initial={softHidden}
            animate={{
              ...softAlive,
              transition: softTran(reduceFx ? 0 : T.delays.sub),
            }}
            className="mt-7 max-w-[520px] font-sans font-medium leading-[1.62] tracking-[-0.012em]"
            style={{
              fontSize: "clamp(17px, 1.42vw, 19px)",
              color: "rgba(32, 28, 23, 0.72)",
            }}
          >
            {data.subheadline}
          </motion.p>

          <motion.div
            initial={softHidden}
            animate={{
              ...softAlive,
              transition: softTran(reduceFx ? 0 : T.delays.cta),
            }}
            className="mt-[1.875rem] flex max-w-[760px] flex-wrap items-start gap-x-10 gap-y-5"
            style={{ pointerEvents: btnsPointerEvents }}
          >
            <HeroPremiumButton
              href="#contacts"
              onClick={scrollTo("contacts")}
            >
              {data.ctaPrimary}
            </HeroPremiumButton>
            <HeroSecondaryLink
              href="#services"
              onClick={scrollTo("services")}
            >
              {data.ctaSecondary}
            </HeroSecondaryLink>
          </motion.div>

          <motion.p
            initial={softHidden}
            animate={{
              ...softAlive,
              transition: softTran(reduceFx ? 0 : T.delays.caption),
            }}
            className="mt-6 max-w-[min(520px,100%)] font-sans text-[13px] font-medium leading-[1.62] tracking-[-0.01em] text-[rgba(32,28,23,0.48)] lg:text-[13.25px]"
          >
            {data.ctaCaption}
          </motion.p>
        </div>
      </div>
    </div>
  );
}

// ─── Mobile ───────────────────────────────────────────────────────────────────

function HeroMobile({
  data,
  dissolve,
  reduceFx,
}: {
  data: SiteHero;
  dissolve: HeroDissolveState;
  reduceFx: boolean;
}) {
  const { opacity, blurPx, scale } = dissolve;
  const btnsPointerEvents = opacity < 0.05 ? "none" : "auto";
  const lines = data.headlineLines;
  const T = heroRevealTimings(lines.length, true, reduceFx);

  const ih = reduceFx
    ? { opacity: 0 }
    : { opacity: 0, y: T.yPx, filter: `blur(${T.blurPx}px)` };
  const ia = reduceFx
    ? { opacity: 1 }
    : { opacity: 1, y: 0, filter: "blur(0px)" };

  const tr = (delay: number) => ({
    duration: reduceFx ? MOTION_DURATION_S.reduced : T.duration,
    ease: T.ease,
    delay,
  });

  const titleStyleMo = {
    fontSize: "clamp(48px, 14vw, 72px)",
    lineHeight: 0.92,
    letterSpacing: "-0.05em",
    fontWeight: 500,
    color: "rgba(28, 24, 20, 0.96)",
  } as const;

  return (
    <div
      className="pointer-events-none absolute inset-0 z-[22] flex flex-col lg:hidden"
      style={{
        opacity,
        ...(blurPx > 0.08 ? { filter: `blur(${blurPx.toFixed(2)}px)` } : {}),
        ...(scale < 0.9995 ? { transform: `scale(${scale.toFixed(4)})` } : {}),
        willChange: "opacity, filter, transform",
      }}
    >
      <div
        aria-hidden
        className="absolute inset-0"
        style={{ background: HERO_SCRIM_MO }}
      />

      <div
        className="relative mx-auto flex w-full max-w-[calc(100vw-32px)] flex-col px-1 xs:max-w-[min(22.5rem,calc(100vw-36px))] xs:px-2"
        style={{
          paddingTop:
            "calc(5.625rem + env(safe-area-inset-top, 0px) + max(14px, 3.75svh))",
        }}
      >
        <motion.div
          initial={ih}
          animate={{
            ...ia,
            transition: tr(reduceFx ? 0 : T.delays.meta),
          }}
        >
          <CoverEyebrow text={data.coverEyebrow} />
        </motion.div>

        <h1 className="m-0 w-full font-display font-medium">
          {lines.map((line, i) => (
            <motion.div
              key={`mo-${i}-${line.slice(0, 8)}`}
              className="overflow-hidden"
              style={{ lineHeight: titleStyleMo.lineHeight }}
              initial={reduceFx ? false : { opacity: 0 }}
              animate={reduceFx ? undefined : { opacity: 1 }}
              transition={
                reduceFx ? undefined : { duration: T.duration * 0.58, ease: T.ease }
              }
            >
              <motion.span
                className="block max-w-[min(18ch,calc(100vw-52px))] font-display xs:max-w-[19ch]"
                style={titleStyleMo}
                initial={
                  reduceFx
                    ? { opacity: 0 }
                    : { y: "1.05em", opacity: 0, filter: `blur(${T.blurPx}px)` }
                }
                animate={
                  reduceFx
                    ? { opacity: 1 }
                    : { y: 0, opacity: 1, filter: "blur(0px)" }
                }
                transition={tr(reduceFx ? 0 : T.delays.lines[i]!)}
              >
                {line}
              </motion.span>
            </motion.div>
          ))}
        </h1>

        <motion.p
          initial={ih}
          animate={{
            ...ia,
            transition: tr(reduceFx ? 0 : T.delays.sub),
          }}
          className="mt-6 max-w-[min(520px,calc(100vw-44px))] font-sans font-medium leading-[1.62]"
          style={{
            fontSize: "clamp(15px, 4.05vw, 16px)",
            color: "rgba(32, 28, 23, 0.72)",
          }}
        >
          {data.subheadline}
        </motion.p>

        <motion.div
          initial={ih}
          animate={{
            ...ia,
            transition: tr(reduceFx ? 0 : T.delays.cta),
          }}
          className="mt-[1.6rem] flex w-full max-w-[min(28rem,calc(100vw-40px))] flex-col items-stretch gap-5 sm:max-w-none sm:flex-row sm:flex-wrap sm:items-start sm:gap-x-12 sm:gap-y-6"
          style={{ pointerEvents: btnsPointerEvents }}
        >
          <HeroPremiumButton fullWidthMobile href="#contacts" onClick={scrollTo("contacts")}>
            {data.ctaPrimary}
          </HeroPremiumButton>

          <HeroSecondaryLink centeredMobile href="#services" onClick={scrollTo("services")}>
            {data.ctaSecondary}
          </HeroSecondaryLink>
        </motion.div>

        <motion.p
          initial={ih}
          animate={{
            ...ia,
            transition: tr(reduceFx ? 0 : T.delays.caption),
          }}
          className="mt-[1.125rem] max-w-[min(520px,calc(100vw-44px))] font-sans text-[12.5px] font-medium leading-[1.6] tracking-[-0.008em] text-[rgba(32,28,23,0.46)] xs:text-[13px]"
        >
          {data.ctaCaption}
        </motion.p>
      </div>
    </div>
  );
}

// ─── Export ───────────────────────────────────────────────────────────────────

export function HeroContent({ variant, data, progress01 }: Props) {
  const narrow = useMediaQuery("(max-width: 1023px)");
  const mqReduce = useMediaQuery("(prefers-reduced-motion: reduce)");
  const fmReduce = useReducedMotion();
  const reduceFx = Boolean(mqReduce || fmReduce);

  const raw: HeroDissolveState =
    typeof progress01 === "number"
      ? heroDissolve(progress01)
      : { opacity: 1, blurPx: 0, scale: 1 };

  const blurFactor = reduceFx ? 0 : narrow ? 0.28 : 1;
  const scaleEase = narrow && !reduceFx ? 0.72 : 1;
  const dissolve: HeroDissolveState = {
    ...raw,
    blurPx: raw.blurPx * blurFactor,
    scale: 1 - (1 - raw.scale) * scaleEase,
  };

  if (variant === "mobile") {
    return <HeroMobile data={data} dissolve={dissolve} reduceFx={reduceFx} />;
  }
  return <HeroDesktop data={data} dissolve={dissolve} reduceFx={reduceFx} />;
}
