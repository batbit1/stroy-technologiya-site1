"use client";

import type {
  KeyboardEvent as ReactKeyboardEvent,
  MouseEvent,
  ReactNode,
} from "react";
import { useCallback, useEffect, useRef, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import {
  EASE_LUXURY,
  MOTION_DURATION_S,
} from "@/lib/motion-system";

const NAV_LINKS = [
  { label: "Главная", href: "#top" },
  { label: "Подход", href: "#services" },
  { label: "Проекты", href: "#portfolio" },
  { label: "Контакты", href: "#contacts" },
] as const;

type NavHref = (typeof NAV_LINKS)[number]["href"];

const HEADER_WORDMARK_PRIMARY = "СТРОЙТЕХНОЛОГИИ";
const HEADER_WORDMARK_TAGLINE = "архитектурная студия под ключ";

/** Текст CTA — справа в шапке и в мобильном drawer. */
const HEADER_CTA = "Обсудить проект";

/** Состояние после скролла — бумага + blur + нижнее правило. */
const HEADER_SCROLLED_BG = "rgba(246, 239, 226, 0.72)";
const HEADER_SCROLLED_BLUR_PX = 14;

const DRAWER_IVORY = `linear-gradient(
  175deg,
  color-mix(in srgb, var(--paper) 88%, transparent) 0%,
  color-mix(in srgb, var(--paper-soft) 72%, transparent) 55%,
  color-mix(in srgb, var(--paper) 78%, transparent) 100%
)`;

const HEADER_PROBE_PX = 56;

function scrollToTarget(href: NavHref) {
  if (href === "#top") {
    window.scrollTo({ top: 0, behavior: "smooth" });
    return;
  }
  document.getElementById(href.slice(1))?.scrollIntoView({
    behavior: "smooth",
    block: "start",
  });
}

function computeActiveHref(): NavHref {
  if (typeof window === "undefined") return "#top";

  const services = document.getElementById("services");
  const probe = HEADER_PROBE_PX;

  if (
    !services ||
    services.getBoundingClientRect().top > probe
  ) {
    return "#top";
  }

  const ordered = ["#services", "#portfolio", "#contacts"] as const;
  let current: NavHref = "#services";

  for (let i = ordered.length - 1; i >= 0; i--) {
    const id = ordered[i].slice(1);
    const el = document.getElementById(id);
    if (!el) continue;
    if (el.getBoundingClientRect().top <= probe) {
      current = ordered[i];
      break;
    }
  }

  return current;
}

function HeaderWordmark({
  onActivate,
}: {
  onActivate: (e: MouseEvent<HTMLAnchorElement>) => void;
}) {
  return (
    <a
      href="#top"
      onClick={onActivate}
      className="group/wordmark relative flex shrink-0 flex-col justify-center gap-1 no-underline outline-none ring-offset-2 ring-offset-transparent transition-opacity duration-[320ms] ease-[var(--luxury-ease)] hover:opacity-[0.92] focus-visible:ring-2 focus-visible:ring-[rgba(32,28,23,0.12)] lg:gap-1.5 min-w-0"
      aria-label={`${HEADER_WORDMARK_PRIMARY} — на главную`}
    >
      <span className="whitespace-nowrap font-display text-[0.9375rem] font-medium uppercase leading-none tracking-[0.125em] text-[rgba(32,28,23,0.94)] lg:text-[0.9625rem]">
        {HEADER_WORDMARK_PRIMARY}
      </span>
      <span className="max-w-[16rem] font-sans text-[10px] font-medium leading-snug tracking-[0.03em] text-[rgba(32,28,23,0.46)] lg:max-w-[18rem] lg:text-[10.25px]">
        {HEADER_WORDMARK_TAGLINE}
      </span>
    </a>
  );
}

/** Десктоп: editorial nav — один ритм трекинга, подчёркивание через scaleX. */
function DesktopNavLink({
  label,
  href,
  active,
  onActivate,
}: {
  label: string;
  href: NavHref;
  active: boolean;
  onActivate: (e: MouseEvent<HTMLAnchorElement>, href: NavHref) => void;
}) {
  const underlineTone = active
    ? "scale-x-100 bg-[rgba(32,28,23,0.34)] opacity-100"
    : [
        "scale-x-0 bg-[rgba(32,28,23,0.28)] opacity-80",
        "group-hover/nav:scale-x-100 group-hover/nav:opacity-100 group-hover/nav:bg-[rgba(32,28,23,0.32)]",
        "group-focus-visible/nav:scale-x-100 group-focus-visible/nav:opacity-100",
      ].join(" ");

  return (
    <a
      href={href}
      onClick={(e) => onActivate(e, href)}
      className={[
        "group/nav relative whitespace-nowrap py-2 font-sans text-[11px] font-semibold uppercase tracking-[0.16em] lg:text-[11.75px]",
        active ? "text-[rgba(32,28,23,0.92)]" : "text-[rgba(32,28,23,0.58)]",
        "[@media(hover:hover)]:hover:text-[rgba(32,28,23,0.92)] focus-visible:text-[rgba(32,28,23,0.92)]",
        "outline-none transition-colors duration-[320ms] ease-[cubic-bezier(0.22,1,0.36,1)]",
      ].join(" ")}
    >
      <span className="relative z-[1]">{label}</span>
      <span
        aria-hidden
        className={[
          "pointer-events-none absolute inset-x-[1px] bottom-[6px] h-px origin-left",
          "transition-[transform,opacity] duration-[720ms] ease-[cubic-bezier(0.22,1,0.36,1)]",
          underlineTone,
        ].join(" ")}
      />
    </a>
  );
}

/** Премиальный outline CTA: прозрачный фон, мягкая ivory-подсветка по hover (без золота). */
function HeaderOutlineCta({
  href,
  onActivate,
  className = "",
  children,
}: {
  href: NavHref;
  className?: string;
  children: ReactNode;
  onActivate: (e: MouseEvent<HTMLAnchorElement>, href: NavHref) => void;
}) {
  const core = [
    "group/cta relative inline-flex shrink-0 items-center justify-center rounded-full",
    "border border-solid border-[rgba(32,28,23,0.18)] bg-transparent",
    "px-[26px] py-3 font-sans text-[11px] font-semibold uppercase tracking-[0.12em]",
    "text-[rgba(32,28,23,0.88)] lg:text-[11.75px]",
    "outline-none ring-offset-2 ring-offset-transparent",
    "transition-[background-color,border-color,color,transform] duration-[340ms]",
    "ease-[cubic-bezier(0.22,1,0.36,1)] active:translate-y-0",
    "[@media(hover:hover)]:hover:-translate-y-px [@media(hover:hover)]:hover:bg-[rgba(255,250,238,0.58)] [@media(hover:hover)]:hover:border-[rgba(32,28,23,0.14)]",
    "focus-visible:ring-2 focus-visible:ring-[rgba(32,28,23,0.1)] focus-visible:bg-[rgba(255,250,238,0.38)]",
  ].join(" ");

  return (
    <a
      href={href}
      onClick={(e) => onActivate(e, href)}
      className={[core, className].filter(Boolean).join(" ")}
    >
      {children}
    </a>
  );
}

function MobileDrawerLink({
  label,
  href,
  active,
  divider,
  onActivate,
}: {
  label: string;
  href: NavHref;
  active: boolean;
  divider?: boolean;
  onActivate: (e: MouseEvent<HTMLAnchorElement>, href: NavHref) => void;
}) {
  return (
    <a
      href={href}
      onClick={(e) => onActivate(e, href)}
      className={[
        "group/mnav relative block px-10 py-5 sm:py-[1.35rem]",
        divider ? "border-t border-[rgba(72,54,42,0.08)]" : "",
        "font-sans text-[clamp(17px,4.7vw,19px)] font-semibold uppercase leading-snug tracking-[0.08em]",
        active ? "text-[rgba(32,28,23,0.92)]" : "text-[rgba(32,28,23,0.72)]",
        "transition-colors duration-[300ms] ease-[cubic-bezier(0.22,1,0.36,1)] hover:text-ink focus-visible:bg-ink/[0.028]",
        "outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-ink/[0.06]",
      ].join(" ")}
    >
      <span>{label}</span>
      <span
        aria-hidden
        className={[
          "pointer-events-none absolute bottom-6 left-10 right-10 h-[1px] origin-left bg-ink/30",
          "transition-[transform,opacity] duration-[760ms] ease-[cubic-bezier(0.22,1,0.36,1)]",
          active
            ? "scale-x-full opacity-100"
            : "scale-x-[0.16] opacity-80 group-hover/mnav:scale-x-full group-hover/mnav:opacity-100 group-focus-visible/mnav:scale-x-full",
        ].join(" ")}
      />
    </a>
  );
}

export function SiteHeader() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [activeHref, setActiveHref] = useState<NavHref>("#top");
  const [drawerMaxPx, setDrawerMaxPx] = useState(560);
  const lastScrollRef = useRef(0);
  const menuBtnRef = useRef<HTMLButtonElement>(null);
  const reduceMotion = useReducedMotion();

  const updateActiveSection = useCallback(() => {
    setActiveHref(computeActiveHref());
  }, []);

  useEffect(() => {
    function capDrawer() {
      setDrawerMaxPx(Math.min(560, Math.round(window.innerHeight * 0.74)));
    }
    capDrawer();

    const onScroll = () => {
      const y = window.scrollY;
      setScrolled(y > 40);
      if (Math.abs(y - lastScrollRef.current) > 28) setMobileOpen(false);
      lastScrollRef.current = y;
      updateActiveSection();
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    const onResize = () => {
      capDrawer();
      updateActiveSection();
    };
    window.addEventListener("resize", onResize, { passive: true });
    onScroll();
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onResize);
    };
  }, [updateActiveSection]);

  useEffect(() => {
    if (!mobileOpen) return;
    const prevBody = document.body.style.overflow;
    const prevHtml = document.documentElement.style.overflow;
    document.documentElement.style.overflow = "hidden";
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prevBody;
      document.documentElement.style.overflow = prevHtml;
    };
  }, [mobileOpen]);

  /** Перенести фокус внутрь drawer после монтирования ссылок — не мешает клавиатуре и SR. */
  useEffect(() => {
    if (!mobileOpen) return;
    let cancelled = false;
    const frame = window.requestAnimationFrame(() => {
      if (cancelled) return;
      document
        .querySelector<HTMLElement>("#site-header-mobile-drawer a[href]")
        ?.focus({ preventScroll: false });
    });
    return () => {
      cancelled = true;
      cancelAnimationFrame(frame);
    };
  }, [mobileOpen]);

  function finalizeCloseMobile(options?: { restoreMenuFocus?: boolean }) {
    setMobileOpen(false);
    if (options?.restoreMenuFocus) {
      queueMicrotask(() =>
        menuBtnRef.current?.focus({ preventScroll: true }),
      );
    }
  }

  function handleLink(
    e: MouseEvent<HTMLAnchorElement>,
    href: NavHref,
  ): void {
    e.preventDefault();
    scrollToTarget(href);
    finalizeCloseMobile();
    queueMicrotask(() => setActiveHref(href));
  }

  function closeMobileMenu() {
    finalizeCloseMobile({ restoreMenuFocus: true });
  }

  const barMotion = reduceMotion
    ? {}
    : {
        initial: { opacity: 0, y: -14 },
        animate: { opacity: 1, y: 0 },
        transition: { duration: MOTION_DURATION_S.section, ease: EASE_LUXURY, delay: 0.04 },
      };

  function onDrawerKeyDown(e: ReactKeyboardEvent<HTMLDivElement>) {
    if (e.key === "Escape") {
      e.preventDefault();
      closeMobileMenu();
    }
  }

  const scrolledBlurPx = scrolled ? `${HEADER_SCROLLED_BLUR_PX}px` : "0px";

  const drawerVariants = reduceMotion
    ? {
        open: {
          opacity: 1,
          maxHeight: drawerMaxPx,
        },
        closed: {
          opacity: 0,
          maxHeight: 0,
        },
      }
    : {
        open: {
          opacity: 1,
          maxHeight: drawerMaxPx,
          backdropFilter: "blur(16px)",
          WebkitBackdropFilter: "blur(16px)",
        },
        closed: {
          opacity: 0,
          maxHeight: 0,
          backdropFilter: "blur(4px)",
          WebkitBackdropFilter: "blur(4px)",
        },
      };

  const drawerTransition = reduceMotion
    ? { duration: 0.05 }
    : {
        opacity: { duration: 0.42, ease: EASE_LUXURY },
        maxHeight: { duration: MOTION_DURATION_S.card, ease: EASE_LUXURY },
        backdropFilter: { duration: MOTION_DURATION_S.micro + 0.22, ease: EASE_LUXURY },
      };

  return (
    <>
      {mobileOpen ? (
        <button
          type="button"
          tabIndex={-1}
          aria-hidden="true"
          className="fixed inset-0 z-[49] cursor-default bg-ink/[0.12] backdrop-blur-[2px] motion-reduce:bg-ink/[0.16] motion-reduce:backdrop-blur-none lg:hidden"
          onClick={closeMobileMenu}
        />
      ) : null}
      <motion.header
        {...(reduceMotion ? {} : barMotion)}
        className="fixed inset-x-0 top-0 z-50 outline-none"
        style={{
          backgroundColor: scrolled ? HEADER_SCROLLED_BG : "transparent",
          backdropFilter: scrolled
            ? `blur(${scrolledBlurPx}) saturate(1.02)`
            : "none",
          WebkitBackdropFilter: scrolled
            ? `blur(${scrolledBlurPx}) saturate(1.02)`
            : "none",
          borderBottomWidth: "1px",
          borderBottomStyle: "solid",
          borderBottomColor: scrolled ? "rgba(72, 54, 36, 0.10)" : "transparent",
          transition:
            "background-color 420ms cubic-bezier(0.22,1,0.36,1), border-bottom-color 420ms cubic-bezier(0.22,1,0.36,1), backdrop-filter 420ms cubic-bezier(0.22,1,0.36,1), -webkit-backdrop-filter 420ms cubic-bezier(0.22,1,0.36,1)",
        }}
        onKeyDown={(e) => {
          if (mobileOpen && e.key === "Escape") {
            e.preventDefault();
            closeMobileMenu();
          }
        }}
      >
        <div
          className="relative mx-auto flex min-h-[72px] max-h-[84px] w-full max-w-[min(1580px,100vw)] items-center justify-between px-[clamp(28px,5vw,96px)]"
          style={{
            paddingTop: "calc(0.5rem + env(safe-area-inset-top, 0px))",
            paddingBottom: "0.5rem",
          }}
        >
          <div className="min-w-0 shrink pr-6">
            <HeaderWordmark onActivate={(e) => handleLink(e, "#top")} />
          </div>

          <nav
            className="pointer-events-none absolute left-1/2 top-1/2 z-[1] hidden max-w-none min-w-0 -translate-x-1/2 -translate-y-1/2 items-center whitespace-nowrap lg:pointer-events-auto lg:flex lg:gap-x-5 xl:gap-x-[1.95rem] 2xl:gap-x-[2.5rem]"
            aria-label="Разделы сайта"
          >
            {NAV_LINKS.map(({ label, href }) => (
              <DesktopNavLink
                key={href}
                label={label}
                href={href}
                active={activeHref === href}
                onActivate={(e, h) => handleLink(e, h)}
              />
            ))}
          </nav>

          <div className="flex shrink-0 items-center gap-3 pl-8 sm:gap-5">
            <HeaderOutlineCta
              href="#contacts"
              onActivate={(e, h) => handleLink(e, h)}
              className="hidden min-h-[46px] lg:inline-flex"
            >
              {HEADER_CTA}
            </HeaderOutlineCta>

            <button
              ref={menuBtnRef}
              type="button"
              aria-label={
                mobileOpen ? "Закрыть меню навигации" : "Открыть меню навигации"
              }
              aria-expanded={mobileOpen}
              aria-controls="site-header-mobile-drawer"
              aria-haspopup="dialog"
              onClick={() => setMobileOpen((v) => !v)}
              className="flex size-11 shrink-0 items-center justify-center rounded-full outline-none ring-offset-2 ring-offset-transparent ring-ink/12 transition-colors hover:bg-[rgba(32,28,23,0.04)] focus-visible:ring-2 lg:hidden"
            >
              <span
                className="flex h-[22px] w-[26px] flex-col items-center justify-center gap-[5px]"
                aria-hidden
              >
                <motion.span
                  className="block h-[1.25px] w-[22px] rounded-full bg-ink/[0.82]"
                  animate={
                    reduceMotion || !mobileOpen
                      ? { rotate: 0, y: 0 }
                      : { rotate: 45, y: 7 }
                  }
                  transition={{ duration: 0.38, ease: EASE_LUXURY }}
                />
                <motion.span
                  className="block h-[1.25px] w-[22px] rounded-full bg-ink/[0.82]"
                  animate={
                    reduceMotion || !mobileOpen
                      ? { opacity: 1, scaleX: 1 }
                      : { opacity: 0, scaleX: 0 }
                  }
                  transition={{ duration: 0.26, ease: EASE_LUXURY }}
                />
                <motion.span
                  className="block h-[1.25px] w-[22px] rounded-full bg-ink/[0.82]"
                  animate={
                    reduceMotion || !mobileOpen
                      ? { rotate: 0, y: 0 }
                      : { rotate: -45, y: -7 }
                  }
                  transition={{ duration: 0.38, ease: EASE_LUXURY }}
                />
              </span>
            </button>
          </div>
        </div>

        <AnimatePresence initial={false}>
          {mobileOpen ? (
            <motion.div
            id="site-header-mobile-drawer"
            role="dialog"
            aria-modal="true"
            aria-label="Разделы сайта, мобильная панель"
            key="mobile-drawer"
            initial="closed"
            animate="open"
            exit="closed"
            variants={drawerVariants}
            transition={drawerTransition}
            style={{
              overflow: "hidden",
              background: DRAWER_IVORY,
              borderTop:
                "1px solid color-mix(in srgb, var(--line) 38%, transparent)",
              boxShadow:
                "inset 0 20px 40px -26px rgba(38,28,22,0.045), inset 0 1px 0 rgba(255,253,248,0.42)",
              willChange: reduceMotion ? "auto" : "opacity, max-height",
            }}
            className="lg:hidden"
            onKeyDown={onDrawerKeyDown}
          >
            <motion.nav
              aria-label="Мобильное меню"
              initial={reduceMotion ? false : { opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={reduceMotion ? undefined : { opacity: 0, y: -4 }}
              transition={{
                duration: reduceMotion ? 0.05 : 0.36,
                ease: EASE_LUXURY,
                delay: reduceMotion ? 0 : 0.06,
              }}
              className="max-h-full overflow-y-auto overscroll-y-contain pb-[calc(16px+env(safe-area-inset-bottom))] pt-1"
            >
              {NAV_LINKS.map(({ label, href }, i) => (
                <MobileDrawerLink
                  key={href}
                  label={label}
                  href={href}
                  active={activeHref === href}
                  divider={i > 0}
                  onActivate={(e, h) => handleLink(e, h)}
                />
              ))}
              <div
                className="mx-8 my-7 h-px bg-gradient-to-r from-transparent via-ink/[0.09] to-transparent sm:mx-10"
                aria-hidden
              />
              <div className="px-8 pb-1 sm:px-10">
                <HeaderOutlineCta
                  href="#contacts"
                  className="flex min-h-[52px] w-full shrink-0 justify-center"
                  onActivate={(e, h) => handleLink(e, h)}
                >
                  {HEADER_CTA}
                </HeaderOutlineCta>
              </div>
            </motion.nav>
            </motion.div>
          ) : null}
        </AnimatePresence>
      </motion.header>
    </>
  );
}
