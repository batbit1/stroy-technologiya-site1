import { SiteHeader } from "@/components/landing/SiteHeader";
import { LandingScrollScene } from "@/components/landing/LandingScrollScene";
import { PortfolioSection } from "@/components/landing/PortfolioSection";
import { ContactSection } from "@/components/landing/ContactSection";

export default function Home() {
  return (
    <>
      {/* Fixed navigation over cinematic scene */}
      <SiteHeader />

      <main id="top">
        {/* Cinematic scroll-sequence — id="services" внутри компонента */}
        <LandingScrollScene />

        {/* Portfolio — якорь для навигации */}
        <div id="portfolio">
          <PortfolioSection />
        </div>

        {/* Contacts — якорь для навигации и CTA-кнопок */}
        <div id="contacts">
          <ContactSection />
        </div>
      </main>
    </>
  );
}
