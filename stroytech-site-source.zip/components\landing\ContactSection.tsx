"use client";

import type { ReactNode } from "react";
import { useInViewOnce } from "@/hooks/useInViewOnce";
import { SITE_CONTENT } from "@/data/siteContent";
import {
  EASE_LUXURY_CSS,
  MOTION_DURATION_MS,
} from "@/lib/motion-system";

const EASE_LUX = EASE_LUXURY_CSS;
const SHOW_MS = MOTION_DURATION_MS.section;
/** Задержка правой колонки относительно левой */
const FORM_COL_DELAY_MS = MOTION_DURATION_MS.contactFormLead;
/** Каскад полей после появления карточки */
const FIELD_STAGGER_MS = MOTION_DURATION_MS.staggerFormFields;

function telHref(phone: string) {
  return `tel:${phone.replace(/\s|\(|\)|-/g, "")}`;
}

/** Редакционная строка контакта — крупно и нажимаемо на touch. */
function EditorialContact({
  eyebrow,
  children,
}: {
  eyebrow: string;
  children: ReactNode;
}) {
  return (
    <div className="group/row relative border-t border-[rgba(105,82,58,0.07)] pb-9 pt-[1.15rem] first:border-t-0 first:pt-0 sm:pb-10">
      <p className="m-0 max-w-[12rem] font-sans text-[11px] font-semibold uppercase leading-relaxed tracking-[0.42em] text-ink/[0.38] sm:text-[11.25px] sm:tracking-[0.46em]">
        {eyebrow}
      </p>
      <div className="mt-4 min-h-[44px] sm:mt-[1.125rem]">{children}</div>
    </div>
  );
}

export function ContactSection() {
  const { contacts } = SITE_CONTENT;

  const { ref: leftRef, isInView: leftIn } = useInViewOnce<HTMLDivElement>({
    rootMargin: "0px 0px -8% 0px",
    threshold: 0,
  });

  const { ref: rightRef, isInView: rightIn } = useInViewOnce<HTMLDivElement>({
    rootMargin: "0px 0px -8% 0px",
    threshold: 0,
  });

  return (
    <section
      className="relative overflow-hidden bg-[#efe8dc] py-[clamp(4.85rem,10vw,7.95rem)]"
      aria-labelledby="contacts-heading"
    >
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse 88% 64% at 10% -6%, rgba(255,251,243,0.78) 0%, transparent 48%), radial-gradient(ellipse 68% 50% at 100% 0%, rgba(244,237,226,0.55) 0%, transparent 45%)",
        }}
      />

      <div className="relative mx-auto max-w-[min(1200px,100%)] px-4 pb-px xs:px-5 sm:px-8 lg:px-14 xl:px-[4.35rem]">
        <div className="grid gap-[clamp(2.85rem,6vw,4.65rem)] lg:grid-cols-[minmax(0,1.02fr)_minmax(0,0.94fr)] lg:items-start lg:gap-x-[clamp(2.85rem,4.5vw,4.85rem)] lg:gap-y-0">
          {/* Левая колонка — приглашение, контакт, процесс */}
          <div
            ref={leftRef}
            inert={!leftIn ? true : undefined}
            style={{
              opacity: leftIn ? 1 : 0,
              transform: leftIn ? "translateY(0)" : "translateY(20px)",
              transition: `opacity ${SHOW_MS}ms ${EASE_LUX}, transform ${SHOW_MS}ms ${EASE_LUX}`,
              pointerEvents: leftIn ? "auto" : "none",
            }}
          >
            <p className="m-0 max-w-[65ch] font-sans text-[11.75px] font-semibold uppercase leading-relaxed tracking-[0.52em] text-ink/[0.42] sm:text-[12px] sm:tracking-[0.54em]">
              {contacts.sectionLabel}
            </p>
            <h2
              id="contacts-heading"
              className="mt-[1rem] max-w-[16ch] text-balance font-display text-[clamp(2.08rem,4.75vw,3.52rem)] font-medium leading-[1.02] tracking-[-0.03em] text-ink/[0.97]"
            >
              {contacts.heading}
            </h2>
            <p className="mt-7 max-w-[48ch] font-sans text-[clamp(1.05rem,2.2vw,1.135rem)] font-medium leading-[1.73] tracking-[-0.012em] text-ink/[0.73] lg:leading-[1.76] lg:tracking-[-0.01em]">
              {contacts.subheading}
            </p>

            <div className="mt-[clamp(2.25rem,4.5vw,3.05rem)]">
              <EditorialContact eyebrow="Телефон">
                <a
                  href={telHref(contacts.phone)}
                  className="inline-flex min-h-[44px] items-center font-sans text-[clamp(1.14rem,2.5vw,1.265rem)] font-semibold tracking-[-0.012em] text-ink/[0.92] underline decoration-[rgba(105,82,58,0.38)] underline-offset-[0.32em] transition-[color,opacity,decoration-color] duration-300 ease-[cubic-bezier(0.22,1,0.36,1)] hover:text-ink hover:decoration-[rgba(105,82,58,0.58)] hover:opacity-95"
                >
                  {contacts.phone}
                </a>
              </EditorialContact>

              <EditorialContact eyebrow={contacts.messengerLabel}>
                <a
                  href={contacts.messengerHref}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex min-h-[44px] items-center gap-2 font-sans text-[clamp(1.035rem,2.35vw,1.155rem)] font-semibold leading-snug tracking-[-0.01em] text-ink/[0.86] underline decoration-[rgba(105,82,58,0.34)] underline-offset-[0.3em] transition-[color,decoration-color,opacity] duration-300 ease-[cubic-bezier(0.22,1,0.36,1)] hover:decoration-[rgba(105,82,58,0.54)] hover:opacity-95"
                >
                  Написать в чат{" "}
                  <span
                    aria-hidden
                    className="text-ink/[0.45] transition-transform duration-300 ease-[cubic-bezier(0.22,1,0.36,1)] group-hover/row:translate-x-px"
                  >
                    ↗
                  </span>
                </a>
              </EditorialContact>

              <EditorialContact eyebrow="Почта">
                <a
                  href={`mailto:${contacts.email}`}
                  className="inline-flex min-h-[44px] max-w-[min(100%,28rem)] flex-wrap items-center font-sans text-[clamp(1.04rem,2.45vw,1.18rem)] font-semibold leading-snug tracking-[-0.012em] text-ink/[0.88] underline decoration-[rgba(105,82,58,0.34)] underline-offset-[0.3em] break-all transition-[color,decoration-color,opacity] duration-300 ease-[cubic-bezier(0.22,1,0.36,1)] hover:decoration-[rgba(105,82,58,0.54)] hover:opacity-95 sm:break-normal"
                >
                  {contacts.email}
                </a>
              </EditorialContact>

              <EditorialContact eyebrow="Офис · география">
                <div className="space-y-2">
                  <p className="m-0 font-sans text-[clamp(1.04rem,2.35vw,1.155rem)] font-medium leading-[1.6] tracking-[-0.01em] text-ink/[0.82]">
                    {contacts.locality}
                  </p>
                  {contacts.address ? (
                    <p className="m-0 max-w-[40ch] font-sans text-[clamp(1.035rem,2.2vw,1.0725rem)] font-medium leading-relaxed tracking-[-0.008em] text-ink/[0.72]">
                      {contacts.address}
                    </p>
                  ) : null}
                </div>
              </EditorialContact>

              <EditorialContact eyebrow="Время связи">
                <p className="m-0 max-w-[40ch] font-sans text-[clamp(1.04rem,2.35vw,1.155rem)] font-medium leading-[1.6] tracking-[-0.01em] text-ink/[0.82]">
                  {contacts.workingHours}
                </p>
              </EditorialContact>
            </div>

            <div className="mt-[clamp(2.85rem,5vw,3.95rem)] max-w-[min(38rem,100%)] border-t border-[rgba(105,82,58,0.08)] pt-[clamp(1.95rem,3vw,2.45rem)]">
              <p className="m-0 font-sans text-[11px] font-semibold uppercase tracking-[0.44em] text-ink/[0.36] sm:text-[11.25px]">
                Как двигается разговор
              </p>
              <ol className="mt-7 list-none space-y-7 p-0 sm:space-y-[1.75rem]">
                {contacts.processSteps.map((step, i) => (
                  <li
                    key={`${i}-${step.slice(0, 12)}`}
                    className="flex gap-5 text-left sm:gap-6"
                  >
                    <span className="shrink-0 pt-px font-display text-[clamp(2.05rem,3vw,2.5rem)] font-medium leading-none tabular-nums tracking-[0.08em] text-ink/[0.16]">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <p className="m-0 max-w-[50ch] font-sans text-[clamp(1.02rem,2.05vw,1.06rem)] font-medium leading-[1.68] text-ink/[0.71] lg:leading-[1.72]">
                      {step}
                    </p>
                  </li>
                ))}
              </ol>
            </div>
          </div>

          {/* Правая колонка — карточка формы */}
          <div
            ref={rightRef}
            inert={!rightIn ? true : undefined}
            style={{ pointerEvents: rightIn ? "auto" : "none" }}
          >
            {/* TODO: подключить server action или API для отправки заявки */}
            <form
              className={[
                "relative flex flex-col gap-0 rounded-[clamp(17px,2.3vw,24px)] border",
                "border-[rgba(72,54,40,0.11)] bg-[rgba(255,251,243,0.47)] backdrop-blur-[10px]",
                "px-[clamp(1.15rem,3.8vw,2.05rem)] py-[clamp(1.5rem,3.9vw,2.35rem)]",
                "shadow-[0_32px_64px_-40px_rgba(38,30,22,0.18),inset_0_1px_0_rgba(255,252,246,0.9)] sm:shadow-[0_36px_70px_-38px_rgba(38,30,22,0.22),inset_0_1px_0_rgba(255,252,246,0.94)]",
                "motion-reduce:backdrop-blur-none lg:transition-shadow lg:duration-[760ms] lg:ease-[cubic-bezier(0.22,1,0.36,1)] [@media(hover:hover)]:lg:hover:shadow-[0_42px_80px_-42px_rgba(36,28,22,0.24)]",
              ].join(" ")}
              onSubmit={(e) => {
                e.preventDefault();
              }}
              aria-label="Заявка на консультацию по дому"
              style={{
                opacity: rightIn ? 1 : 0,
                transform: rightIn ? "translateY(0)" : "translateY(26px)",
                transition: `opacity ${SHOW_MS}ms ${EASE_LUX}, transform ${SHOW_MS}ms ${EASE_LUX}`,
                transitionDelay: rightIn ? `${FORM_COL_DELAY_MS}ms` : "0ms",
              }}
            >
              <fieldset className="m-0 grid gap-0 border-0 p-0">
                <legend className="sr-only">
                  Короткая заявка: имя, телефон, тип задачи и сообщение.
                </legend>

                {/* Имя */}
                <div
                  style={{
                    opacity: rightIn ? 1 : 0,
                    transform: rightIn ? "translateY(0)" : "translateY(16px)",
                    transition: `opacity ${SHOW_MS}ms ${EASE_LUX}, transform ${SHOW_MS}ms ${EASE_LUX}`,
                    transitionDelay: rightIn
                      ? `${FORM_COL_DELAY_MS + FIELD_STAGGER_MS * 0}ms`
                      : "0ms",
                  }}
                >
                  <label
                    htmlFor="contact-name"
                    className="mb-4 block font-sans text-[12px] font-semibold uppercase tracking-[0.28em] text-ink/[0.44] sm:text-[12.25px]"
                  >
                    Имя
                  </label>
                  <input
                    id="contact-name"
                    type="text"
                    name="name"
                    placeholder="Как к вам обращаться"
                    autoComplete="name"
                    required={false}
                    className="w-full rounded-2xl border border-[rgba(72,54,40,0.12)] bg-[rgba(251,246,239,0.38)] px-[1.125rem] py-[1.05rem] font-sans text-[1.065rem] leading-normal text-ink shadow-[inset_0_1px_0_rgba(255,252,246,0.72)] outline-none placeholder:text-ink/[0.35] motion-reduce:transition-none transition-[border-color,box-shadow,background-color] duration-300 ease-[cubic-bezier(0.22,1,0.36,1)] focus-visible:border-[rgba(105,82,58,0.52)] focus-visible:bg-[rgba(255,251,246,0.58)] focus-visible:shadow-[0_0_0_3px_rgba(105,82,58,0.12)] focus-visible:outline-none xs:px-5 sm:px-[1.25rem] sm:py-[1.12rem]"
                  />
                </div>

                {/* Телефон */}
                <div
                  className="mt-8 border-t border-[rgba(105,82,58,0.06)] pt-8"
                  style={{
                    opacity: rightIn ? 1 : 0,
                    transform: rightIn ? "translateY(0)" : "translateY(16px)",
                    transition: `opacity ${SHOW_MS}ms ${EASE_LUX}, transform ${SHOW_MS}ms ${EASE_LUX}`,
                    transitionDelay: rightIn
                      ? `${FORM_COL_DELAY_MS + FIELD_STAGGER_MS * 1}ms`
                      : "0ms",
                  }}
                >
                  <label
                    htmlFor="contact-phone"
                    className="mb-4 block font-sans text-[12px] font-semibold uppercase tracking-[0.28em] text-ink/[0.44] sm:text-[12.25px]"
                  >
                    Телефон
                  </label>
                  <input
                    id="contact-phone"
                    type="tel"
                    name="phone"
                    placeholder="+7"
                    autoComplete="tel"
                    required={false}
                    className="w-full rounded-2xl border border-[rgba(72,54,40,0.12)] bg-[rgba(251,246,239,0.38)] px-[1.125rem] py-[1.05rem] font-sans text-[1.065rem] leading-normal tracking-wide text-ink shadow-[inset_0_1px_0_rgba(255,252,246,0.72)] outline-none placeholder:text-ink/[0.35] transition-[border-color,box-shadow,background-color] duration-300 ease-[cubic-bezier(0.22,1,0.36,1)] focus-visible:border-[rgba(105,82,58,0.52)] focus-visible:bg-[rgba(255,251,246,0.58)] focus-visible:shadow-[0_0_0_3px_rgba(105,82,58,0.12)] focus-visible:outline-none motion-reduce:transition-none xs:px-5 sm:px-[1.25rem] sm:py-[1.12rem]"
                  />
                </div>

                {/* Тип задачи */}
                <div
                  className="mt-8 border-t border-[rgba(105,82,58,0.06)] pt-8"
                  style={{
                    opacity: rightIn ? 1 : 0,
                    transform: rightIn ? "translateY(0)" : "translateY(16px)",
                    transition: `opacity ${SHOW_MS}ms ${EASE_LUX}, transform ${SHOW_MS}ms ${EASE_LUX}`,
                    transitionDelay: rightIn
                      ? `${FORM_COL_DELAY_MS + FIELD_STAGGER_MS * 2}ms`
                      : "0ms",
                  }}
                >
                  <label
                    htmlFor="contact-request-type"
                    className="mb-4 block font-sans text-[12px] font-semibold uppercase tracking-[0.28em] text-ink/[0.44] sm:text-[12.25px]"
                  >
                    Что нужно решить первым делом
                  </label>
                  <div className="relative">
                    <select
                      id="contact-request-type"
                      name="requestType"
                      defaultValue=""
                      className="w-full cursor-pointer appearance-none rounded-2xl border border-[rgba(72,54,40,0.12)] bg-[rgba(251,246,239,0.38)] px-[1.125rem] py-[1.05rem] font-sans text-[1.06rem] leading-normal text-ink shadow-[inset_0_1px_0_rgba(255,252,246,0.72)] outline-none transition-[border-color,box-shadow,background-color] duration-300 ease-[cubic-bezier(0.22,1,0.36,1)] focus-visible:border-[rgba(105,82,58,0.52)] focus-visible:bg-[rgba(255,251,246,0.58)] focus-visible:shadow-[0_0_0_3px_rgba(105,82,58,0.12)] focus-visible:outline-none motion-reduce:transition-none xs:px-5 sm:px-[1.25rem] sm:py-[1.12rem]"
                    >
                      <option value="" disabled>
                        Выберите тип запроса
                      </option>
                      <option value="construction">
                        Новое строительство дома
                      </option>
                      <option value="reconstruction">
                        Реконструкция или пристройка
                      </option>
                      <option value="design">
                        Проектирование и комплект документации
                      </option>
                    </select>
                    <span
                      aria-hidden
                      className="pointer-events-none absolute right-6 top-1/2 -translate-y-1/2 text-[9px] font-semibold tracking-[0.24em] text-ink/[0.32]"
                    >
                      ▼
                    </span>
                  </div>
                </div>

                {/* Сообщение */}
                <div
                  className="mt-8 border-t border-[rgba(105,82,58,0.06)] pt-8"
                  style={{
                    opacity: rightIn ? 1 : 0,
                    transform: rightIn ? "translateY(0)" : "translateY(16px)",
                    transition: `opacity ${SHOW_MS}ms ${EASE_LUX}, transform ${SHOW_MS}ms ${EASE_LUX}`,
                    transitionDelay: rightIn
                      ? `${FORM_COL_DELAY_MS + FIELD_STAGGER_MS * 3}ms`
                      : "0ms",
                  }}
                >
                  <label
                    htmlFor="contact-message"
                    className="mb-4 block font-sans text-[12px] font-semibold uppercase tracking-[0.28em] text-ink/[0.44] sm:text-[12.25px]"
                  >
                    Контур задачи или участка
                  </label>
                  <textarea
                    id="contact-message"
                    name="message"
                    rows={5}
                    placeholder="От опорной информации будет проще продолжить разговор: участок, площадь, текущее здание, сроки."
                    required={false}
                    className="w-full resize-y rounded-2xl border border-[rgba(72,54,40,0.12)] bg-[rgba(251,246,239,0.38)] px-[1.125rem] py-[1.05rem] font-sans text-[1.06rem] leading-[1.62] text-ink shadow-[inset_0_1px_0_rgba(255,252,246,0.72)] outline-none placeholder:text-ink/[0.35] transition-[border-color,box-shadow,background-color] duration-300 ease-[cubic-bezier(0.22,1,0.36,1)] focus-visible:border-[rgba(105,82,58,0.52)] focus-visible:bg-[rgba(255,251,246,0.58)] focus-visible:shadow-[0_0_0_3px_rgba(105,82,58,0.12)] focus-visible:outline-none motion-reduce:transition-none min-h-[10rem] xs:px-5 sm:px-[1.25rem] sm:py-[1.12rem] sm:leading-[1.64] sm:min-h-[9.75rem]"
                  />
                </div>

                <div
                  className="mt-11 border-t border-[rgba(105,82,58,0.06)] pt-10"
                  style={{
                    opacity: rightIn ? 1 : 0,
                    transform: rightIn ? "translateY(0)" : "translateY(14px)",
                    transition: `opacity ${SHOW_MS}ms ${EASE_LUX}, transform ${SHOW_MS}ms ${EASE_LUX}`,
                    transitionDelay: rightIn
                      ? `${FORM_COL_DELAY_MS + FIELD_STAGGER_MS * 4}ms`
                      : "0ms",
                  }}
                >
                  <button
                    type="submit"
                    className="group/submit relative isolate w-full overflow-hidden rounded-2xl border border-[rgba(72,54,40,0.19)] px-8 py-[1.15rem] text-center font-sans text-[1rem] font-semibold uppercase tracking-[0.16em] text-ink/[0.9] shadow-[inset_0_1px_0_rgba(255,252,246,0.55)] outline-none transition-[transform,border-color,box-shadow,color] duration-300 ease-[cubic-bezier(0.22,1,0.36,1)] focus-visible:border-[rgba(105,82,58,0.42)] focus-visible:shadow-[0_0_0_3px_rgba(105,82,58,0.13)] focus-visible:outline-none active:translate-y-0 motion-reduce:transition-none [@media(hover:hover)]:lg:hover:-translate-y-0.5 sm:py-[1.22rem] sm:tracking-[0.18em]"
                  >
                    <span
                      aria-hidden
                      className="pointer-events-none absolute inset-0 origin-left scale-x-0 bg-gradient-to-r from-[rgba(237,229,212,0.55)] via-[rgba(218,196,172,0.36)] to-[rgba(226,212,188,0.26)] opacity-95 transition-[transform] duration-[720ms] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover/submit:scale-x-100 group-focus-visible/submit:scale-x-100"
                    />
                    <span className="relative z-[1]">{contacts.ctaLabel}</span>
                  </button>

                  <p className="mx-auto mt-6 max-w-[34ch] text-center font-sans text-[clamp(0.9625rem,2.05vw,1.03rem)] font-medium leading-[1.6] tracking-[-0.008em] text-ink/[0.62] lg:leading-[1.65] lg:tracking-[-0.006em]">
                    {contacts.trustNote}
                  </p>

                  <p className="mt-8 border-t border-[rgba(105,82,58,0.05)] pt-8 text-center font-sans text-[11px] leading-[1.6] tracking-[0.02em] text-ink/[0.34] sm:text-[11.25px]">
                    Нажимая кнопку, вы принимаете обработку персональных данных
                    исключительно для ответа по заявке.
                  </p>
                </div>
              </fieldset>
            </form>
          </div>
        </div>
      </div>

      {/* Подвал сайта */}
        <div className="relative mx-auto mt-[clamp(3.95rem,7vw,5.75rem)] max-w-[min(1200px,100%)] border-t border-[rgba(105,82,58,0.085)] px-4 pt-[clamp(2rem,4vw,2.75rem)] xs:px-5 sm:px-8 lg:px-14 xl:px-[4.35rem]">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between sm:gap-6">
          <p className="m-0 font-sans text-[1.0625rem] font-semibold tracking-[-0.014em] text-ink/[0.88]">
            {SITE_CONTENT.hero.brand}
          </p>
          <p className="m-0 font-sans text-[0.98rem] tracking-[-0.01em] text-ink/[0.52]">
            © {new Date().getFullYear()} — все права защищены
          </p>
        </div>
      </div>
    </section>
  );
}
