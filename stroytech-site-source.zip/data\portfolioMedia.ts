/**
 * Визуальные ассеты портфолио.
 *
 * Положите реальные фотографии в `public/portfolio/` с теми же именами,
 * что в `imageSrc` у `SITE_CONTENT.portfolio.items` (или обновите пути).
 *
 * `blurDataURL` — микро-превью для `next/image` `placeholder="blur"` (лёгкий ivory).
 */
export const PORTFOLIO_IMAGE_BLUR_DATA_URL =
  "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8/5+hHgAHggJ/PgO6pQAAAABJRU5ErkJggg==";
